#ifndef RESOURCE_H_INCLUDED
#define RESOURCE_H_INCLUDED

//APP DEFS
#define CURVERSION "alpha 0.2"
//Res
#define DEFAULT_FONT_RES_PTH "res/fonts/default.ttf"
#define LOGO_PTH "res/imgs/logo.png"

#endif // RESOURCE_H_INCLUDED
