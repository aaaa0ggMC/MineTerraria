#ifndef SCDTA_H_INCLUDED
#define SCDTA_H_INCLUDED

///Scene Data
#define SC_START_UP 0
#define SC_LOADING 1
#define SC_MENU 2
#define SC_MODS 3
#define SC_WORLD 4

#endif // SCDTA_H_INCLUDED
