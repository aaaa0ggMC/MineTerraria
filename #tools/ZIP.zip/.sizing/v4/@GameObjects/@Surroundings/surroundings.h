#ifndef SURROUNDINGS_H_INCLUDED
#define SURROUNDINGS_H_INCLUDED
#include "../../kernel.h"

//Namespace:GameObject
namespace go{
    class Cloud{
    public:
        void Move(float x,float y);

    };
}

#endif // SURROUNDINGS_H_INCLUDED
