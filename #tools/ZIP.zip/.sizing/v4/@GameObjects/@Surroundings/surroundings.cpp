#include "surroundings.h"
using namespace go;

void Cloud::Move(float x,float y){

}
